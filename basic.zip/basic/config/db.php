<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=icomp',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
